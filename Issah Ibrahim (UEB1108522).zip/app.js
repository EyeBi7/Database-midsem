const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const path = require('path');
const fs = require('fs').promises;
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static('uploads'));

// Database connection
const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'political_party_db'
};

let db;

// Initialize database connection
async function initializeDB() {
  try {
    db = await mysql.createConnection(dbConfig);
    console.log('Connected to MySQL database');
    await createTables();
  } catch (error) {
    console.error('Database connection failed:', error);
    process.exit(1);
  }
}

// File upload configuration
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + Math.round(Math.random() * 1E9) + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage,
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB limit
  }
});

// JWT middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key', (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid token' });
    }
    req.user = user;
    next();
  });
};

// Create database tables
async function createTables() {
  const tables = [
    // Users table for admin authentication
    `CREATE TABLE IF NOT EXISTS users (
      id INT AUTO_INCREMENT PRIMARY KEY,
      username VARCHAR(50) UNIQUE NOT NULL,
      email VARCHAR(100) UNIQUE NOT NULL,
      password_hash VARCHAR(255) NOT NULL,
      role ENUM('admin', 'editor', 'viewer') DEFAULT 'viewer',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )`,

    // Party information
    `CREATE TABLE IF NOT EXISTS party_info (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      description TEXT,
      mission TEXT,
      vision TEXT,
      founded_date DATE,
      logo_url VARCHAR(255),
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )`,

    // Leaders
    `CREATE TABLE IF NOT EXISTS leaders (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(100) NOT NULL,
      position VARCHAR(100) NOT NULL,
      bio TEXT,
      image_url VARCHAR(255),
      order_priority INT DEFAULT 0,
      is_active BOOLEAN DEFAULT TRUE,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )`,

    // Media/News articles
    `CREATE TABLE IF NOT EXISTS media_articles (
      id INT AUTO_INCREMENT PRIMARY KEY,
      title VARCHAR(255) NOT NULL,
      content TEXT,
      excerpt TEXT,
      author VARCHAR(100),
      category ENUM('news', 'press_release', 'statement', 'event') DEFAULT 'news',
      image_url VARCHAR(255),
      published_date DATETIME,
      is_featured BOOLEAN DEFAULT FALSE,
      is_published BOOLEAN DEFAULT FALSE,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )`,

    // Party projects
    `CREATE TABLE IF NOT EXISTS party_projects (
      id INT AUTO_INCREMENT PRIMARY KEY,
      title VARCHAR(255) NOT NULL,
      description TEXT,
      detailed_description TEXT,
      status ENUM('planned', 'in_progress', 'completed', 'on_hold') DEFAULT 'planned',
      start_date DATE,
      end_date DATE,
      budget DECIMAL(12,2),
      image_url VARCHAR(255),
      is_featured BOOLEAN DEFAULT FALSE,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )`,

    // Events
    `CREATE TABLE IF NOT EXISTS events (
      id INT AUTO_INCREMENT PRIMARY KEY,
      title VARCHAR(255) NOT NULL,
      description TEXT,
      location VARCHAR(255),
      event_date DATETIME NOT NULL,
      end_date DATETIME,
      is_public BOOLEAN DEFAULT TRUE,
      max_attendees INT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )`,

    // Contact messages
    `CREATE TABLE IF NOT EXISTS contact_messages (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(100) NOT NULL,
      email VARCHAR(100) NOT NULL,
      subject VARCHAR(255),
      message TEXT NOT NULL,
      is_read BOOLEAN DEFAULT FALSE,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,

    // Newsletter subscriptions
    `CREATE TABLE IF NOT EXISTS newsletter_subscriptions (
      id INT AUTO_INCREMENT PRIMARY KEY,
      email VARCHAR(100) UNIQUE NOT NULL,
      is_active BOOLEAN DEFAULT TRUE,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`
  ];

  for (const table of tables) {
    try {
      await db.execute(table);
      console.log('Table created successfully');
    } catch (error) {
      console.error('Error creating table:', error);
    }
  }

  // Insert default admin user if not exists
  await createDefaultAdmin();
}

// Create default admin user
async function createDefaultAdmin() {
  try {
    const [rows] = await db.execute('SELECT COUNT(*) as count FROM users WHERE role = "admin"');
    if (rows[0].count === 0) {
      const hashedPassword = await bcrypt.hash('admin123', 10);
      await db.execute(
        'INSERT INTO users (username, email, password_hash, role) VALUES (?, ?, ?, ?)',
        ['admin', 'admin@thenewcongress.com', hashedPassword, 'admin']
      );
      console.log('Default admin user created: admin/admin123');
    }
  } catch (error) {
    console.error('Error creating default admin:', error);
  }
}

// Routes

// Authentication Routes
app.post('/api/auth/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    
    const [rows] = await db.execute('SELECT * FROM users WHERE username = ? OR email = ?', [username, username]);
    
    if (rows.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const user = rows[0];
    const validPassword = await bcrypt.compare(password, user.password_hash);
    
    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = jwt.sign(
      { id: user.id, username: user.username, role: user.role },
      process.env.JWT_SECRET || 'your-secret-key',
      { expiresIn: '24h' }
    );

    res.json({
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Login failed' });
  }
});

// Party Info Routes
app.get('/api/party-info', async (req, res) => {
  try {
    const [rows] = await db.execute('SELECT * FROM party_info ORDER BY created_at DESC LIMIT 1');
    res.json(rows[0] || {});
  } catch (error) {
    console.error('Error fetching party info:', error);
    res.status(500).json({ error: 'Failed to fetch party information' });
  }
});

app.put('/api/party-info', authenticateToken, async (req, res) => {
  try {
    const { name, description, mission, vision, founded_date } = req.body;
    
    const [existing] = await db.execute('SELECT COUNT(*) as count FROM party_info');
    
    if (existing[0].count === 0) {
      await db.execute(
        'INSERT INTO party_info (name, description, mission, vision, founded_date) VALUES (?, ?, ?, ?, ?)',
        [name, description, mission, vision, founded_date]
      );
    } else {
      await db.execute(
        'UPDATE party_info SET name = ?, description = ?, mission = ?, vision = ?, founded_date = ? WHERE id = (SELECT * FROM (SELECT id FROM party_info ORDER BY created_at DESC LIMIT 1) AS temp)',
        [name, description, mission, vision, founded_date]
      );
    }
    
    res.json({ message: 'Party information updated successfully' });
  } catch (error) {
    console.error('Error updating party info:', error);
    res.status(500).json({ error: 'Failed to update party information' });
  }
});

// Leaders Routes
app.get('/api/leaders', async (req, res) => {
  try {
    const [rows] = await db.execute(
      'SELECT * FROM leaders WHERE is_active = TRUE ORDER BY order_priority DESC, created_at ASC'
    );
    res.json(rows);
  } catch (error) {
    console.error('Error fetching leaders:', error);
    res.status(500).json({ error: 'Failed to fetch leaders' });
  }
});

app.post('/api/leaders', authenticateToken, upload.single('image'), async (req, res) => {
  try {
    const { name, position, bio, order_priority } = req.body;
    const image_url = req.file ? `/uploads/${req.file.filename}` : null;
    
    const [result] = await db.execute(
      'INSERT INTO leaders (name, position, bio, image_url, order_priority) VALUES (?, ?, ?, ?, ?)',
      [name, position, bio, image_url, order_priority || 0]
    );
    
    res.status(201).json({ 
      id: result.insertId, 
      message: 'Leader added successfully' 
    });
  } catch (error) {
    console.error('Error adding leader:', error);
    res.status(500).json({ error: 'Failed to add leader' });
  }
});

app.put('/api/leaders/:id', authenticateToken, upload.single('image'), async (req, res) => {
  try {
    const { id } = req.params;
    const { name, position, bio, order_priority } = req.body;
    const image_url = req.file ? `/uploads/${req.file.filename}` : null;
    
    let query = 'UPDATE leaders SET name = ?, position = ?, bio = ?, order_priority = ?';
    let params = [name, position, bio, order_priority || 0];
    
    if (image_url) {
      query += ', image_url = ?';
      params.push(image_url);
    }
    
    query += ' WHERE id = ?';
    params.push(id);
    
    await db.execute(query, params);
    res.json({ message: 'Leader updated successfully' });
  } catch (error) {
    console.error('Error updating leader:', error);
    res.status(500).json({ error: 'Failed to update leader' });
  }
});

app.delete('/api/leaders/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    await db.execute('UPDATE leaders SET is_active = FALSE WHERE id = ?', [id]);
    res.json({ message: 'Leader removed successfully' });
  } catch (error) {
    console.error('Error removing leader:', error);
    res.status(500).json({ error: 'Failed to remove leader' });
  }
});

// Media Routes
app.get('/api/media', async (req, res) => {
  try {
    const { category, featured, limit = 20, offset = 0 } = req.query;
    
    let query = 'SELECT * FROM media_articles WHERE is_published = TRUE';
    let params = [];
    
    if (category) {
      query += ' AND category = ?';
      params.push(category);
    }
    
    if (featured === 'true') {
      query += ' AND is_featured = TRUE';
    }
    
    query += ' ORDER BY published_date DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));
    
    const [rows] = await db.execute(query, params);
    res.json(rows);
  } catch (error) {
    console.error('Error fetching media:', error);
    res.status(500).json({ error: 'Failed to fetch media articles' });
  }
});

app.get('/api/media/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await db.execute('SELECT * FROM media_articles WHERE id = ? AND is_published = TRUE', [id]);
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Article not found' });
    }
    
    res.json(rows[0]);
  } catch (error) {
    console.error('Error fetching article:', error);
    res.status(500).json({ error: 'Failed to fetch article' });
  }
});

app.post('/api/media', authenticateToken, upload.single('image'), async (req, res) => {
  try {
    const { title, content, excerpt, author, category, published_date, is_featured } = req.body;
    const image_url = req.file ? `/uploads/${req.file.filename}` : null;
    
    const [result] = await db.execute(
      'INSERT INTO media_articles (title, content, excerpt, author, category, image_url, published_date, is_featured, is_published) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [title, content, excerpt, author, category || 'news', image_url, published_date || new Date(), is_featured || false, true]
    );
    
    res.status(201).json({ 
      id: result.insertId, 
      message: 'Article created successfully' 
    });
  } catch (error) {
    console.error('Error creating article:', error);
    res.status(500).json({ error: 'Failed to create article' });
  }
});

// Party Projects Routes
app.get('/api/party-projects', async (req, res) => {
  try {
    const { status, featured, limit = 20, offset = 0 } = req.query;
    
    let query = 'SELECT * FROM party_projects WHERE 1=1';
    let params = [];
    
    if (status) {
      query += ' AND status = ?';
      params.push(status);
    }
    
    if (featured === 'true') {
      query += ' AND is_featured = TRUE';
    }
    
    query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));
    
    const [rows] = await db.execute(query, params);
    res.json(rows);
  } catch (error) {
    console.error('Error fetching party projects:', error);
    res.status(500).json({ error: 'Failed to fetch party projects' });
  }
});

app.post('/api/party-projects', authenticateToken, upload.single('image'), async (req, res) => {
  try {
    const { title, description, detailed_description, status, start_date, end_date, budget, is_featured } = req.body;
    const image_url = req.file ? `/uploads/${req.file.filename}` : null;
    
    const [result] = await db.execute(
      'INSERT INTO party_projects (title, description, detailed_description, status, start_date, end_date, budget, image_url, is_featured) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [title, description, detailed_description, status || 'planned', start_date, end_date, budget, image_url, is_featured || false]
    );
    
    res.status(201).json({ 
      id: result.insertId, 
      message: 'Project created successfully' 
    });
  } catch (error) {
    console.error('Error creating project:', error);
    res.status(500).json({ error: 'Failed to create project' });
  }
});

// Events Routes
app.get('/api/events', async (req, res) => {
  try {
    const { upcoming, limit = 20, offset = 0 } = req.query;
    
    let query = 'SELECT * FROM events WHERE is_public = TRUE';
    let params = [];
    
    if (upcoming === 'true') {
      query += ' AND event_date > NOW()';
    }
    
    query += ' ORDER BY event_date ASC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));
    
    const [rows] = await db.execute(query, params);
    res.json(rows);
  } catch (error) {
    console.error('Error fetching events:', error);
    res.status(500).json({ error: 'Failed to fetch events' });
  }
});

app.post('/api/events', authenticateToken, async (req, res) => {
  try {
    const { title, description, location, event_date, end_date, is_public, max_attendees } = req.body;
    
    const [result] = await db.execute(
      'INSERT INTO events (title, description, location, event_date, end_date, is_public, max_attendees) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [title, description, location, event_date, end_date, is_public !== false, max_attendees]
    );
    
    res.status(201).json({ 
      id: result.insertId, 
      message: 'Event created successfully' 
    });
  } catch (error) {
    console.error('Error creating event:', error);
    res.status(500).json({ error: 'Failed to create event' });
  }
});

// Contact Routes
app.post('/api/contact', async (req, res) => {
  try {
    const { name, email, subject, message } = req.body;
    
    if (!name || !email || !message) {
      return res.status(400).json({ error: 'Name, email, and message are required' });
    }
    
    const [result] = await db.execute(
      'INSERT INTO contact_messages (name, email, subject, message) VALUES (?, ?, ?, ?)',
      [name, email, subject || '', message]
    );
    
    res.status(201).json({ 
      id: result.insertId, 
      message: 'Message sent successfully' 
    });
  } catch (error) {
    console.error('Error saving contact message:', error);
    res.status(500).json({ error: 'Failed to send message' });
  }
});

app.get('/api/contact', authenticateToken, async (req, res) => {
  try {
    const { unread, limit = 50, offset = 0 } = req.query;
    
    let query = 'SELECT * FROM contact_messages';
    let params = [];
    
    if (unread === 'true') {
      query += ' WHERE is_read = FALSE';
    }
    
    query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));
    
    const [rows] = await db.execute(query, params);
    res.json(rows);
  } catch (error) {
    console.error('Error fetching contact messages:', error);
    res.status(500).json({ error: 'Failed to fetch messages' });
  }
});

// Newsletter Routes
app.post('/api/newsletter/subscribe', async (req, res) => {
  try {
    const { email } = req.body;
    
    if (!email) {
      return res.status(400).json({ error: 'Email is required' });
    }
    
    const [result] = await db.execute(
      'INSERT INTO newsletter_subscriptions (email) VALUES (?) ON DUPLICATE KEY UPDATE is_active = TRUE',
      [email]
    );
    
    res.status(201).json({ message: 'Successfully subscribed to newsletter' });
  } catch (error) {
    console.error('Error subscribing to newsletter:', error);
    res.status(500).json({ error: 'Failed to subscribe' });
  }
});

// Search functionality
app.get('/api/search', async (req, res) => {
  try {
    const { q, type } = req.query;
    
    if (!q) {
      return res.status(400).json({ error: 'Search query is required' });
    }
    
    const searchTerm = `%${q}%`;
    const results = {};
    
    if (!type || type === 'all' || type === 'media') {
      const [mediaResults] = await db.execute(
        'SELECT id, title, excerpt, category, published_date FROM media_articles WHERE is_published = TRUE AND (title LIKE ? OR content LIKE ?) ORDER BY published_date DESC LIMIT 10',
        [searchTerm, searchTerm]
      );
      results.media = mediaResults;
    }
    
    if (!type || type === 'all' || type === 'projects') {
      const [projectResults] = await db.execute(
        'SELECT id, title, description, status FROM party_projects WHERE title LIKE ? OR description LIKE ? ORDER BY created_at DESC LIMIT 10',
        [searchTerm, searchTerm]
      );
      results.projects = projectResults;
    }
    
    if (!type || type === 'all' || type === 'leaders') {
      const [leaderResults] = await db.execute(
        'SELECT id, name, position, bio FROM leaders WHERE is_active = TRUE AND (name LIKE ? OR position LIKE ?) ORDER BY order_priority DESC LIMIT 10',
        [searchTerm, searchTerm]
      );
      results.leaders = leaderResults;
    }
    
    if (!type || type === 'all' || type === 'events') {
      const [eventResults] = await db.execute(
        'SELECT id, title, description, location, event_date FROM events WHERE is_public = TRUE AND (title LIKE ? OR description LIKE ?) ORDER BY event_date ASC LIMIT 10',
        [searchTerm, searchTerm]
      );
      results.events = eventResults;
    }
    
    res.json(results);
  } catch (error) {
    console.error('Error performing search:', error);
    res.status(500).json({ error: 'Search failed' });
  }
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Error handling middleware
app.use((error, req, res, next) => {
  console.error('Unhandled error:', error);
  res.status(500).json({ error: 'Internal server error' });
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// Initialize and start server
async function startServer() {
  try {
    // Create uploads directory if it doesn't exist
    await fs.mkdir('uploads', { recursive: true });
    
    // Initialize database
    await initializeDB();
    
    // Start server
    app.listen(PORT, () => {
      console.log(`🚀 Server running on port ${PORT}`);
      console.log(`📊 Health check: http://localhost:${PORT}/api/health`);
      console.log(`🔐 Default admin credentials: admin / admin123`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();

module.exports = app;